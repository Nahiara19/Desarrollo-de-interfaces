# Variables adicionales
lives = 3
special_item = None  # El objeto especial será un diccionario o None si no está activo
special_item_speed = 8
special_item_img = cv2.imread('special_item.png', cv2.IMREAD_UNCHANGED)
special_item_img = cv2.resize(special_item_img, (50, 50))
special_item_active = False

# Dentro del bucle principal:
while True:
    ret, frame = cap.read()
    if not ret:
        break

    # Redimensionar y procesar el cuadro
    frame = cv2.resize(frame, (width, height))
    frame = cv2.flip(frame, 1)
    image_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    # Procesar la imagen para detectar manos
    results = hands.process(image_rgb)

    # Detectar gestos de la mano
    if results.multi_hand_landmarks:
        for hand_landmarks in results.multi_hand_landmarks:
            mp_drawing.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)
            index_finger_x = int(hand_landmarks.landmark[mp_hands.HandLandmark.INDEX_FINGER_TIP].x * width)
            index_finger_y = int(hand_landmarks.landmark[mp_hands.HandLandmark.INDEX_FINGER_TIP].y * height)
            player_position_x = index_finger_x
            player_position_y = index_finger_y

    # Limitar el movimiento del jugador
    player_position_x = max(0, min(width - 50, player_position_x))
    player_position_y = max(0, min(height - 50, player_position_y))

    # Crear el objeto especial si no existe en el nivel
    if not special_item_active and random.randint(1, 100) == 1:
        special_item_x = random.randint(0, width - 50)
        special_item = [special_item_x, 0]
        special_item_active = True

    # Dibujar y mover el objeto especial
    if special_item:
        special_item[1] += special_item_speed
        overlay_image(frame, special_item_img, special_item[0], special_item[1])
        if special_item[1] > height:
            special_item = None
            special_item_active = False

    # Colisión con el objeto especial
    if special_item:
        if (player_position_x < special_item[0] + 50 and
                player_position_x + 50 > special_item[0] and
                player_position_y < special_item[1] + 50 and
                player_position_y + 50 > special_item[1]):
            special_item = None
            special_item_active = False
            # Efecto especial del objeto: sumar vida o puntos, según prefieras
            lives += 1  # Por ejemplo, sumar una vida

    # Dibujar y mover obstáculos
    for obstacle in obstacles:
        obstacle[1] += obstacle_speed
        obstacle[0] += obstacle[2] * 5
        if obstacle[0] <= 0 or obstacle[0] >= width - 50:
            obstacle[2] *= -1
        overlay_image(frame, obstacle_img, obstacle[0], obstacle[1])

    # Detectar colisiones con obstáculos
    for obstacle in obstacles:
        if (player_position_x < obstacle[0] + 50 and
                player_position_x + 50 > obstacle[0] and
                player_position_y < obstacle[1] + 50 and
                player_position_y + 50 > obstacle[1]):
            obstacles.remove(obstacle)  # Eliminar obstáculo
            lives -= 1  # Restar una vida
            if lives == 0:  # Terminar el juego si vidas = 0
                cv2.putText(frame, 'GAME OVER', (width // 2 - 100, height // 2), cv2.FONT_HERSHEY_SIMPLEX, 2, (0, 0, 255), 3)
                cv2.imshow('Recolecta monedas', frame)
                cv2.waitKey(0)
                cap.release()
                cv2.destroyAllWindows()
                exit()

    # Dibujar el jugador
    overlay_image(frame, player_img, player_position_x, player_position_y)

    # Mostrar vidas en la pantalla
    cv2.putText(frame, f'Vidas: {lives}', (10, 150), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)

    # Mostrar la ventana del juego
    cv2.imshow('Recolecta monedas', frame)

    # Salir si se presiona 'q'
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Liberar recursos
cap.release()
cv2.destroyAllWindows()
 